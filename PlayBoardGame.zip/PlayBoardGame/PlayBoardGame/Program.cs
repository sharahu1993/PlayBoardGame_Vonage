﻿using System;

namespace PlayBoardGame
{
    internal class Program
    {/// <summary>
     /// Main method calling GetCoordinateDirection
     /// user provides instructions 
     /// </summary>
     /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Enter instructions");
            string input = Console.ReadLine();
            string output = PlayBoard.GetCoordinateDirection(input);
            Console.WriteLine(output);
            Console.ReadLine();
        }
    }
}
