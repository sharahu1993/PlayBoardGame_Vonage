﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayBoardGame
{
    public class PlayBoard
    { 
        /// <summary>
        /// Get coordinate and direction based on user input
        /// User can move in any direction N, E, W ,S based on R and L direction given by user in instructions
        /// </summary>
        /// <param name="inputCommand">input command from user</param>
        /// <returns></returns>
        public static string GetCoordinateDirection(string inputCommand)
        {
            int[,] board = new int[5, 5];
            int row = 0, col = 0;
            char direction = 'N';
            string output = "0 0 N";

            if (string.IsNullOrEmpty(inputCommand))
                return output;
            for (int i = 0; i < inputCommand.Length; i++)
            {
                switch (inputCommand[i])
                {
                    case 'M':
                        GetCoordinates(ref row, ref col, ref direction, board.GetLength(0));
                        break;
                    case 'R':
                        direction = GetDirectionOnTurningRigt(direction);
                        break;
                    case 'L':
                        direction = GetDirectionOnTurningLeft(direction);
                        break;
                    default:
                        output = "Enter correct direction and Command";
                        return output;
                }

            }
            output = $"{row} {col} {direction}";
            return output;
        }
        /// <summary>
        /// Get coordinates on instruction "M" to move ahead in given direction
        /// </summary>
        /// <param name="row">row in board</param>
        /// <param name="col">column in board</param>
        /// <param name="direction">Direction of user, initially North</param>
        /// <param name="maxBoardLength">Length of the playing board, given 5</param>
        static void GetCoordinates(ref int row, ref int col, ref char direction, int maxBoardLength)
        {

            switch (direction)
            {
                case 'E':
                    row++;
                    break;
                case 'W':
                    row--;
                    break;
                case 'N':
                    col++;
                    break;
                case 'S':
                    col--;
                    break;
            }
            if (row < 0)
                row = 0;

            if (col < 0)
                col = 0;

            if (col >= maxBoardLength)
                col = maxBoardLength - 1;

            if (row >= maxBoardLength)
                row = maxBoardLength - 1;
        }
        /// <summary>
        /// Get direction on Turning Right
        /// </summary>
        /// <param name="direction">Direction given by user in instruction</param>
        /// <returns></returns>
        static char GetDirectionOnTurningRigt(char direction)
        {
            char netDirection = '\0';
            switch (direction)
            {
                case 'N':
                    netDirection = 'E';
                    break;
                case 'S':
                    netDirection = 'W';
                    break;
                case 'E':
                    netDirection = 'S';
                    break;
                case 'W':
                    netDirection = 'N';
                    break;
            }

            return netDirection;
        }
        /// <summary>
        ///  Get direction on Turning Left
        /// </summary>
        /// <param name="direction">Direction given by user in instruction</param>
        /// <returns></returns>
        static char GetDirectionOnTurningLeft(char direction)
        {
            char netDirection = '\0';
            switch (direction)
            {
                case 'N':
                    netDirection = 'W';
                    break;
                case 'S':
                    netDirection = 'E';
                    break;
                case 'E':
                    netDirection = 'N';
                    break;
                case 'W':
                    netDirection = 'S';
                    break;
            }
            return netDirection;

        }
    }
}
