﻿using NUnit.Framework;
using PlayBoardGame;

namespace PlayingBoardGameTest.TestMethods
{
    internal class PlayBoardTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestAllCommand()
        {
            //PlayBoard playBoard = new PlayBoard();
            string result =PlayBoard.GetCoordinateDirection("MRMLMRM");
            Assert.IsTrue(result == "2 2 E");
        }
        [Test]
        public void TestGenericCommands()
        {
            //PlayBoard playBoard = new PlayBoard();
            string result = PlayBoard.GetCoordinateDirection("RMMMLMM");
            Assert.IsTrue(result == "3 2 N");
        }

        [Test]
        public void TestEdgeCase()
        {
            //PlayBoard playBoard = new PlayBoard();
            string result = PlayBoard.GetCoordinateDirection("MMMMM");
            Assert.IsTrue(result == "0 4 N");
        }

        [Test]
        public void TestRightCommand()
        {
            //PlayBoard playBoard = new PlayBoard();
            string result = PlayBoard.GetCoordinateDirection("RRRRRR");
            Assert.IsTrue(result == "0 0 S");
        }
    }
}
